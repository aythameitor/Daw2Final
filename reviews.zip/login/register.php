<?php
/**
 * Se encarga de realizar el registro de los user
 * @author Aythami Miguel Cabrera Mayor
 * @category File
 * @throws PDOException
 * @uses /funciones/codificar.php
 * @uses /funciones/querys.php
 */
session_name("loveGamingSession2023");
session_start();
if (isset($_SESSION["email"]) && $_SESSION["roleId"] == 1) {
    header("location:/index.php");
    die();
}
include $_SERVER['DOCUMENT_ROOT'] . "/functions/functions.php";

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (!empty($_FILES['profilePic']['name'])) {
            $nombre_archivo = $_FILES['profilePic']['name'];
            $tipo_archivo = $_FILES['profilePic']['type'];
            $tamano_archivo = $_FILES['profilePic']['size'];
            $tempRoute = $_FILES['profilePic']['tmp_name'];
            $fileInfo = pathinfo($nombre_archivo);
            $extension = $fileInfo['extension'];
        }

        $birthDate = date('Y-m-d', strtotime($_POST['dateOfBirth']));
        $username = strip_tags(trim($_POST["username"]));
        $telephone = strip_tags(trim($_POST["telephone"]));
        $email = strip_tags(trim($_POST["email"]));
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
        $connection = connection();
        $emailCheck = select("userId", $email, $connection);
        $usernameCheck = check("username", $username, $connection);
        $userId = select("userId", $email, $connection);

        //valida que el campo sea un email, y en caso de serlo comprueba si hay post de admin y si tu roleId es de superadmin
        if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
            $mensajeFallo = "Por favor, introduce un email válido";
        } else {
            if ($emailCheck->rowCount() == 0) {

                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    if ($usernameCheck->rowCount() == 0) {
                        if ($username != "") {
                            if (!empty($_FILES['profilePic']['name'])) {
                                if ($_FILES['profilePic']['size'] <= 2097152) {
                                    if (strpos($tipo_archivo, 'image') !== false) {
                                        // Mover la imagen cargada a una ubicación permanente en el servidor
                                        if ($_FILES['profilePic']['error'] === UPLOAD_ERR_OK) {
                                            if (isset($_POST['admin']) && $_POST["admin"] == "valid" && select("roleId", $_SESSION["email"], $connection)->fetchColumn() == 3) {
                                                $sql = "insert into user (email, password, username, telephone, dateOfBirth, roleId) values (:email, :password, :username, :telephone, :birthDate, 2)";
                                                $query = $connection->prepare($sql);
                                                $query->bindParam(":email", $email, PDO::PARAM_STR);
                                                $query->bindParam(":password", $password, PDO::PARAM_STR);
                                                $query->bindParam(":username", $username, PDO::PARAM_STR);
                                                $query->bindParam(":telephone", $telephone, PDO::PARAM_INT);
                                                $query->bindParam(":birthDate", $birthDate, PDO::PARAM_STR);
                                                $query->execute();

                                                $newUserId = select("userId", $email, $connection)->fetchColumn();
                                                $ruta_destino = '../images/profilePics/' . $newUserId . "." . $extension;
                                                $ruta_BBDD = '/images/profilePics/' . $newUserId . "." . $extension;

                                                if (move_uploaded_file($tempRoute, $ruta_destino)) {
                                                    $sqlRouteUpdatePic = "update user set profilePic = :profilePic where userId = :userId";
                                                    $queryRouteUpdatePic = $connection->prepare($sqlRouteUpdatePic);
                                                    $queryRouteUpdatePic->bindParam(":profilePic", $ruta_BBDD, PDO::PARAM_STR);
                                                    $queryRouteUpdatePic->bindParam(":userId", $newUserId);
                                                    $queryRouteUpdatePic->execute();
                                                    $success = "Admin created successfully";

                                                } else {
                                                    $mensajeFallo = "Ha ocurrido un error al mover la foto";
                                                }
                                            } else {
                                                $sql = "insert into user (email, password, username, telephone, dateOfBirth) values (:email, :password, :username, :telephone, :birthDate)";
                                                $query = $connection->prepare($sql);
                                                $query->bindParam(":email", $email, PDO::PARAM_STR);
                                                $query->bindParam(":password", $password, PDO::PARAM_STR);
                                                $query->bindParam(":username", $username, PDO::PARAM_STR);
                                                $query->bindParam(":telephone", $telephone, PDO::PARAM_INT);
                                                $query->bindParam(":birthDate", $birthDate, PDO::PARAM_STR);
                                                $query->execute();
                                                if (!isset($_SESSION["email"])) {
                                                    $_SESSION["email"] = $email;
                                                    $_SESSION["roleId"] = 1;
                                                }
                                                $newUserId = select("userId", $email, $connection)->fetchColumn();
                                                $ruta_destino = '../images/profilePics/' . $newUserId . "." . $extension;
                                                $ruta_BBDD = '/images/profilePics/' . $newUserId . "." . $extension;
                                                if (move_uploaded_file($tempRoute, $ruta_destino)) {
                                                    $sqlRouteUpdatePic = "update user set profilePic = :profilePic where userId = :userId";
                                                    $queryRouteUpdatePic = $connection->prepare($sqlRouteUpdatePic);
                                                    $queryRouteUpdatePic->bindParam(":profilePic", $ruta_BBDD, PDO::PARAM_STR);
                                                    $queryRouteUpdatePic->bindParam(":userId", $newUserId);
                                                    $queryRouteUpdatePic->execute();
                                                    $success = "User created successfully";

                                                } else {
                                                    $mensajeFallo = "Ha ocurrido un error al mover la foto";
                                                }
                                            }
                                        } else {
                                            $mensajeFallo = "No se ha podido mover la imagen";
                                        }
                                    } else {
                                        $mensajefallo = 'El archivo cargado no es válido';
                                    }
                                } else {
                                    $mensajeFallo = 'El archivo es muy grande debe pesar menos de 2MB';
                                }
                            } else {
                                if (isset($_POST['admin']) && $_POST["admin"] == "valid" && select("roleId", $_SESSION["email"], $connection)->fetchColumn() == 3) {
                                    $sql = "insert into user (email, password, username, telephone, dateOfBirth, roleId) values (:email, :password, :username, :telephone, :birthDate, 2)";
                                    $query = $connection->prepare($sql);
                                    $query->bindParam(":email", $email, PDO::PARAM_STR);
                                    $query->bindParam(":password", $password, PDO::PARAM_STR);
                                    $query->bindParam(":username", $username, PDO::PARAM_STR);
                                    $query->bindParam(":telephone", $telephone, PDO::PARAM_INT);
                                    $query->bindParam(":birthDate", $birthDate, PDO::PARAM_STR);
                                    $query->execute();
                                    $success = "Admin created successfully";
                                } else {
                                    $sql = "insert into user (email, password, username, telephone, dateOfBirth) values (:email, :password, :username, :telephone, :birthDate)";
                                    $query = $connection->prepare($sql);
                                    $query->bindParam(":email", $email, PDO::PARAM_STR);
                                    $query->bindParam(":password", $password, PDO::PARAM_STR);
                                    $query->bindParam(":username", $username, PDO::PARAM_STR);
                                    $query->bindParam(":telephone", $telephone, PDO::PARAM_INT);
                                    $query->bindParam(":birthDate", $birthDate, PDO::PARAM_STR);
                                    $query->execute();

                                    if (!isset($_SESSION["email"])) {
                                        $_SESSION["email"] = $email;
                                        $_SESSION["roleId"] = 1;
                                    }
                                    $success = "User created successfully";
                                }
                            }
                        } else {
                            $mensajeFallo = "Username cannot be empty";
                        }
                    } else {
                        $mensajeFallo = "Username is already taken";
                    }
                } else {
                    $mensajeFallo = "Email is not valid";
                }
            } else {
                $mensajeFallo = "Email is already taken";
            }
        }
    } else if (isset($_SESSION["email"])) {
        $email = $_SESSION["email"];
        $connection = connection();
        $roleId = $_SESSION["roleId"];
        if ($roleId == 1) {
            header("location:" . $_SERVER['DOCUMENT_ROOT'] . "/index.php");
            die();
        }
    }
} catch (PDOException $error) {
    $error = $error->getMessage();
}

require '../parts/header.php';

if (isset($success)) {
    echo "<div'>
    <div>
        <div>
            <div>
                 $success
            </div>
        </div>
    </div>
</div>";
}
if (isset($mensajeFallo)) {
    echo "<div'>
    <div>
        <div>
            <div>
                 $mensajeFallo 
            </div>
        </div>
    </div>
</div>";
} ?>

<?php
if (isset($error)) {
    ?>
    <div>
        <div>
            <div>
                <div>
                    <?= $error ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}
?>

<div class="container">
    <form action="" method="post" enctype="multipart/form-data">
        <h2>Registro</h2>
        <div class="form-group">
            <label>Email:</label><input type="text" name="email" class="form-control" /><br />
        </div>
        <div class="form-group">
            <label>Password:</label><input type="password" name="password" id="passwordField" class="form-control" />
            <br /> <button type="button" onclick="showPassword()" class="btn btn-primary">Show</button><br /><br />
        </div>
        <div class="form-group">
            <label>Username:</label><input type="text" name="username" class="form-control" /><br />
        </div>
        <div class="form-group">
            <label>DateOfBirth:</label><input type="date" name="dateOfBirth" class="form-control" /><br />
        </div>
        <div class="form-group">
            <label>Telephone:</label><input type="tel" name="telephone" class="form-control" /><br />
        </div>
        <div class="form-group">
            <label>ProfilePic:</label><input type="file" name="profilePic" id="profilePic" accept="image/*"
                class="form-control" /><br />
        </div>

        <?php
        if (isset($_SESSION["roleId"])) {

            if ($_SESSION["roleId"] == 3) {
                ?>
                <div class="form-group">
                    <label for="admin">Admin:</label>
                    <input type="checkbox" name="admin" value="valid">
                </div>
                <?php
            }
        }

        ?>
        <input type="submit" value="Enviar" /><br />
    </form>
</div>
<?php
require $_SERVER['DOCUMENT_ROOT'] . '/parts/footer.php';
?>
<script>
    function showPassword() {
        var passwordField = document.getElementById("passwordField");
        if (passwordField.type === "password") {
            passwordField.type = "text";
        } else {
            passwordField.type = "password";
        }
    }

    const fileInput = document.getElementById("profilePic");

    fileInput.addEventListener("change", () => {
        if (fileInput.files[0].size > 2097152) {
            alert("El tamaño máximo permitido para la imagen es de 2MB.");
            fileInput.value = "";
        }
    });
</script>