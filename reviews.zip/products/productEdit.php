<?php
/**
 * Se encarga de realizar el registro de los user
 * @author Aythami Miguel Cabrera Mayor
 * @category File
 * @throws PDOException
 * @uses /funciones/codificar.php
 * @uses /funciones/querys.php
 */
session_name("loveGamingSession2023");
session_start();
if (isset($_SESSION["email"]) && $_SESSION["roleId"] == 1) {
    header("location:/index.php");
    die();
}
include $_SERVER['DOCUMENT_ROOT'] . "/functions/functions.php";

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (!empty($_FILES['picture']['name'])) {
            $nombre_archivo = $_FILES['picture']['name'];
            $tipo_archivo = $_FILES['picture']['type'];
            $tamano_archivo = $_FILES['picture']['size'];
            $tempRoute = $_FILES['picture']['tmp_name'];
            $fileInfo = pathinfo($nombre_archivo);
            $extension = $fileInfo['extension'];
        }

        $releaseDate = date('Y-m-d', strtotime($_POST['releaseDate']));
        $description = strip_tags(trim($_POST["description"]));
        $stock = strip_tags(trim($_POST["stock"]));
        $product = strip_tags(trim($_POST["product"]));
        $productId = strip_tags(trim($_POST["productId"]));
        $price = strip_tags(trim($_POST["price"]));
        $productType = strip_tags(trim($_POST["productType"]));

        $connection = connection();

        $productTypeQuery = "select productTypeId from producttype where productType = :productType";
        $productTypeExecQuery = $connection->prepare($productTypeQuery);
        $productTypeExecQuery->bindParam(":productType", $productType, PDO::PARAM_STR);
        $productTypeExecQuery->execute();
        $productTypeId = $productTypeExecQuery->fetchColumn();

        //valida que el campo sea un email, y en caso de serlo comprueba si hay post de admin y si tu roleId es de superadmin

        if (!empty($_FILES['picture']['name'])) {
            if ($_FILES['picture']['size'] <= 2097152) {
                if (strpos($tipo_archivo, 'image') !== false) {
                    // Mover la imagen cargada a una ubicación permanente en el servidor
                    if ($_FILES['picture']['error'] === UPLOAD_ERR_OK) {
                        $ruta_destino = '../images/products/' . $product . "." . $extension;
                        $ruta_BBDD = '/images/products/' . $product . "." . $extension;
                        if (move_uploaded_file($tempRoute, $ruta_destino)) {
                            if (select("roleId", $_SESSION["email"], $connection)->fetchColumn() > 1) {
                                $sql = "UPDATE product SET productTypeId = :productTypeId, releaseDate = :releaseDate, price = :price, name = :name, description = :description, picture = :picture, stock = :stock WHERE productId = :id";
                                $query = $connection->prepare($sql);
                                $query->bindParam(":productTypeId", $productTypeId, PDO::PARAM_STR);
                                $query->bindParam(":releaseDate", $releaseDate, PDO::PARAM_STR);
                                $query->bindParam(":price", $price);
                                $query->bindParam(":name", $product, PDO::PARAM_STR);
                                $query->bindParam(":description", $description, PDO::PARAM_STR);
                                $query->bindParam(":picture", $ruta_BBDD, PDO::PARAM_STR);
                                $query->bindParam(":stock", $stock);
                                $query->bindParam(":id", $productId, PDO::PARAM_INT);
                                $query->execute();
                                $success = "Product updated successfully";
                            }
                        } else {
                            $mensajeFallo = "Ha ocurrido un error al mover la foto";
                        }
                    } else {
                        $mensajeFallo = "No se ha podido mover la imagen";
                    }
                } else {
                    $mensajefallo = 'El archivo cargado no es válido';
                }
            } else {
                $mensajeFallo = 'El archivo es muy grande debe pesar menos de 2MB';
            }
        } else {
            if (select("roleId", $_SESSION["email"], $connection)->fetchColumn() > 1) {
                $sql = "UPDATE product SET productTypeId = :productTypeId, releaseDate = :releaseDate, price = :price, name = :name, description = :description, stock = :stock WHERE productId = :id";
                $query = $connection->prepare($sql);
                $query->bindParam(":productTypeId", $productTypeId, PDO::PARAM_STR);
                $query->bindParam(":releaseDate", $releaseDate, PDO::PARAM_STR);
                $query->bindParam(":price", $price);
                $query->bindParam(":name", $product, PDO::PARAM_STR);
                $query->bindParam(":description", $description, PDO::PARAM_STR);
                $query->bindParam(":stock", $stock);
                $query->bindParam(":id", $productId, PDO::PARAM_INT);
                $query->execute();

                $pictureOldRoute = "SELECT picture FROM product where productId = :valuee";
                $pictureOldRouteQuery = $connection->prepare($pictureOldRoute);
                $pictureOldRouteQuery->bindParam(":valuee", $productId);
                $pictureOldRouteQuery->execute();
                $oldPicture = $pictureOldRouteQuery->fetchColumn();
                $oldPictureAbsolute = realpath($_SERVER['DOCUMENT_ROOT'] . $oldPicture);
                var_dump($oldPictureAbsolute);
                if($oldPicture != "/images/products/default.png"){
                    $extension = pathinfo($oldPicture, PATHINFO_EXTENSION);
                    $newPicture = "/images/products/" . $product . "." . $extension;
                    $newPictureAbsolute = realpath($_SERVER['DOCUMENT_ROOT'] . $newPicture);
                    var_dump($newPictureAbsolute);
                    $sqlPic = "update product set picture = :newPicture where productId = :productId";
                    $queryUpdatePic = $connection->prepare($sqlPic);
                    $queryUpdatePic->bindParam(":productId", $productId);
                    $queryUpdatePic->bindParam(":newPicture", $newPicture);
                    $queryUpdatePic->execute();

                    $newPictureRoute = "../images/products/" . $product . "." . $extension;
                    if (rename($oldPictureAbsolute, $newPictureAbsolute)) {
                        echo "El archivo ha sido renombrado exitosamente.";
                    } else {
                        echo "Ha habido un error al renombrar el archivo.";
                    }
                }


                $success = "Product updated successfully";
            }
        }

    }
    if (isset($_SESSION["email"])) {
        $email = $_SESSION["email"];
        $connection = connection();
        $roleId = $_SESSION["roleId"];
        if ($roleId == 1) {
            header("location:" . $_SERVER['DOCUMENT_ROOT'] . "/index.php");
            die();
        }
    }
} catch (PDOException $error) {
    $error = $error->getMessage();
}

require '../parts/header.php';

if (isset($success)) {
    echo "<div class='container p-2'>
    <div>
        <div>
            <div>
                 $success
            </div>
        </div>
    </div>
</div>";
}
if (isset($mensajeFallo)) {
    echo "<div class='container p-2'>
    <div>
        <div>
            <div>
                 $mensajeFallo 
            </div>
        </div>
    </div>
</div>";
} ?>

<?php
if (isset($error)) {
    ?>
    <div>
        <div>
            <div>
                <div>
                    <?= $error ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $productId = strip_tags(trim($_GET["product"]));
    $sql = "SELECT * FROM product where productId = :valuee";
    $query = $connection->prepare($sql);
    $query->bindParam(":valuee", $productId);
    $query->execute();
    $queryProductValues = $query->fetch();
    ?>

    <div>
        <img src="<?= $queryProductValues["picture"]; ?>" alt="" srcset="" width="50px" height="50px">
        <form action="" method="post" enctype="multipart/form-data">
            <h2>Edit product</h2>
            <label>id:</label><input type="number" name="productId" value="<?= $productId; ?>" readonly /><br /><br />
            <label>name:</label><input type="text" name="product" value="<?= $queryProductValues["name"]; ?>" /><br /><br />
            <label>description:</label><input type="text" name="description"
                value="<?= $queryProductValues["description"]; ?>" /><br /><br />
            <label>price:</label><input type="number" step="0.01" name="price"
                value="<?= $queryProductValues["price"]; ?>" /><br /><br />
            <label>release date:</label><input type="date" name="releaseDate"
                value="<?= $queryProductValues["releaseDate"]; ?>" /><br /><br />
            <label>stock:</label><input type="number" name="stock"
                value="<?= $queryProductValues["stock"]; ?>" /><br /><br />
            <label>product type:</label><select name="productType">
                <?php
                $allTypes = 'select * from productType';
                $typesQuery = $connection->prepare($allTypes);
                $typesQuery->execute();
                $types = $typesQuery->fetchAll();
                foreach ($types as $row) {
                    if ($row['productTypeId'] == $queryProductValues["productTypeId"]) {
                        echo "<option value='" . $row['productType'] . "' selected>" . $row['productType'] . "</option>";
                    } else {
                        echo "<option value='" . $row['productType'] . "'>" . $row['productType'] . "</option>";
                    }
                }
                ?>
            </select><br /><br />
            <label>picture:</label><input type="file" name="picture" id="picture" accept="image/*" /><br /><br />

            <input type="submit" value="Enviar" /><br />
        </form>
    </div>
    <?php
} else {
    ?>
    <div>
        <form action="" method="post" enctype="multipart/form-data">
            <h2>Add product</h2>
            <label>name:</label><input type="text" name="product" /><br /><br />
            <label>description:</label><input type="text" name="description" /><br /><br />
            <label>price:</label><input type="number" step="0.01" name="price" /><br /><br />
            <label>release date:</label><input type="date" name="releaseDate" /><br /><br />
            <label>stock:</label><input type="number" name="stock" /><br /><br />
            <label>product type:</label><select name="productType">
                <?php
                $allTypes = 'select * from productType';
                $typesQuery = $connection->prepare($allTypes);
                $typesQuery->execute();
                $types = $typesQuery->fetchAll();
                foreach ($types as $row) {
                    echo "<option value='" . $row['productType'] . "'>" . $row['productType'] . "</option>";
                }
                ?>
            </select><br /><br />
            <label>picture:</label><input type="file" name="picture" id="picture" accept="image/*" /><br /><br />
            <input type="submit" value="Enviar" /><br />
        </form>
    </div>

    <?php
}
require $_SERVER['DOCUMENT_ROOT'] . '/parts/footer.php';
?>