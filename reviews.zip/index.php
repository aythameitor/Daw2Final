<html>

<head>
    <title>Prueba de PHP</title>
</head>

<body>

    <?php
    session_name("loveGamingSession2023");
    session_start();

    include 'functions/functions.php';
    try {
        $connection = connection();

    $AllProductsQuery = 'select * from product';
    $sentencia = $connection->prepare($AllProductsQuery);
    $sentencia->execute();
    $product = $sentencia->fetchAll();
} catch (PDOException $error) {
    $error = $error->getMessage();
}
    include 'parts/header.php';
    ?>

    <section>
        <h1 class="text-center">Cheap games in Gran Canaria</h1>
        <p class="text-center mt-3">Discover a wide selection of cheap games and immerse yourself in the thrilling world of gaming with Lovegaming in Gran Canaria.</p>
    </section>

    <section>
        <div class="margin-50"></div>
        <div class="margin-50"></div>
    </section>

    <section>
        <div class="container">
        <div class="row">

        <?php
    if ($product && $sentencia->rowCount() > 0) {
        for ($i=0; $i < 4; $i++) { 
            ?>
            <div class="card" style="width: 18rem; margin:10px;">
                <img style="width:100%;height:262px;object-fit:cover" class="card-img-top" src='<?php echo $product[$i]["picture"]; ?>'>
                <div class="card-body">
                    <h5 class="card-title">
                        <?php
                        if (isset($_SESSION["roleId"]) && $_SESSION["roleId"] > 1) {
                            echo "productId" . $product[$i]["productId"];
                        }
                        ?>
                        <?php echo "<br>" . "Name: " . $product[$i]["name"]; ?>

                    </h5>
                    <p class="card-text">
                        Release date:
                        <?php echo $product[$i]["releaseDate"]; ?> <br>
                        Price:
                        <?php echo $product[$i]["price"]; ?> <br>
                        Description:
                        <?php echo $product[$i]["description"]; ?> <br>
                        Stock:
                        <?php echo $product[$i]["stock"]; ?> <br>
                        Product type:
                        <?php
                        $rol = 'select productType from productType where productTypeId=' . $product[$i]["productTypeId"];
                        $consultaRol = $connection->prepare($rol);
                        $consultaRol->execute();
                        $nombreRol = $consultaRol->fetchColumn();
                        echo $nombreRol;
                        ?> <br>

                    <div style="display:flex;justify-content:center">
                        <?php
                        if (isset($_SESSION["roleId"]) && $_SESSION["roleId"] > 1) {
                            ?>
                            <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg"
                                style="display:flex;justify-content:center;align-items:center">
                                <a href="productList.php?delete=<?php echo $product[$i]["productId"]; ?>">
                                    <image href="/images/svg/trash-can.svg" height="25" width="25">
                                </a>
                            </svg>
                                <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg"
                                    style="display:flex;justify-content:center;align-items:center">
                                    <a href="productEdit.php?product=<?php echo $product[$i]["productId"]; ?>">
                                        <image href="/images/svg/pen.svg" height="25" width="25">
                                    </a>
                                </svg>
                            <?php
                        }
                        ?>
                    </div>
                    <div style="display:flex;justify-content:space-between">
                    <?php
                    if (isset($_SESSION["roleId"]) && $_SESSION["roleId"] < 2) {
                        $checkWishQuery = "select * from wishlist where productId = :productId and userId = :userId";
                        $checkWish = $connection->prepare($checkWishQuery);
                        $checkWish->bindParam(":productId", $product[$i]['productId']);
                        $idCheckWish = select("userId", $_SESSION["email"], $connection)->fetchColumn();
                        $checkWish->bindParam(":userId", $idCheckWish);
                        $checkWish->execute();
                        if ($checkWish->rowCount() > 0) {
                            ?>

                            <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg"
                                style="display:flex;justify-content:center;align-items:center">
                                <a href="productList.php?wishlist=<?php echo $product[$i]["productId"]; ?>">
                                    <image href="/images/svg/loved-product.svg" height="25" width="25">
                                </a>
                            </svg>

                        <?php
                        } else {
                            ?>
                            <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg"
                                style="display:flex;justify-content:center;align-items:center">
                                <a href="productList.php?wishlist=<?php echo $product[$i]["productId"]; ?>">
                                    <image href="/images/svg/love.svg" height="25" width="25">
                                </a>
                            </svg>

                        <?php
                        }
                        
                    }
                    ?>
                    <?php
                if (isset($_SESSION["roleId"]) && $_SESSION["roleId"] < 2) {
                    ?>

                        <svg width="25" height="25" xmlns="http://www.w3.org/2000/svg"
                            style="display:flex;justify-content:center;align-items:center">
                            <a href="productList.php?cart=<?php echo $product[$i]["productId"]; ?>">
                                <image href="/images/svg/cart.svg" height="25" width="25">
                            </a>
                        </svg>

                    <?php
                }
                ?>
                    </div>
                    </p>

                </div>
            </div>

            <?php
        }

    }
    ?>
                </div>
                </div>
    </section>
    <div class="margin-50"></div>
    <div class="margin-50"></div>
    <section class="parallaxSection">
        <div class="parallaxBackgroundImg"></div>
        <div class="textParallax">
            <p>
                This is text!
            </p>
        </div>
    </section>
    <?php
    require $_SERVER['DOCUMENT_ROOT'] . '/parts/footer.php';
    ?>

</body>

</html>